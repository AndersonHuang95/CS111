// Simpleton Shell
// CS111 Winter 2016
// Eggert 
// Lab 1A 

// Note: errors do not cause simpleton shell to exit. The shell tries its best to 
// finish parsing all options. A diagnostic message is sent to stderr if an action 
// could not be finished. 

#include <unistd.h> 
#include <fcntl.h> 
#include <errno.h> 
#include <getopt.h> 
#include <stdlib.h>
#include <stdio.h> 
#include <signal.h>
#include <sys/wait.h>
#include <sys/stat.h> 
#include <sys/types.h>
#include <ctype.h>

#define TABLE_SIZE 100 
// Boilerplate code 

int verbose_flag = 0;
int table_size = TABLE_SIZE; 
int table_index = 0; 

// Fix this up later 
static char* usage = "usage: ./simpsh [OPTION]... [STREAM]... [FILE]..."; 

// getopt_long signature 
/* int getopt_long(int argc, char * const argv[],
           const char *optstring,
           const struct option *longopts, int *longindex);
*/ 
// Recall program name is argv[0]

static struct option long_options[] = {
	/* These options do not set a flag. */ 
	{"rdonly",	required_argument, 0, 'r'}, 
	{"wronly", required_argument, 0, 'w'}, 
	{"command", required_argument, 0, 'c'}, 
	/* These options do set a flag. */ 
	{"verbose", no_argument, &verbose_flag, 1},
	{0, 0, 0, 0}
	};

int main(int argc, char** argv){
	int* file_desc_table = (int*) malloc(table_size * sizeof(int)); 
	if (!file_desc_table) {
		fprintf(stderr, "Memory allocation for file descriptor table failed. Exiting Simpleton Shell."); 
		exit(1); 
	}
	 
	int fd; // file descriptor 
	int optchar; // stores value returned by getopt_long
	char* filename; // stores parameter if option takes an argument 
	// int optind, opterr, optopt;  in order, current index in argv, ?, invalid character if found
	int long_index = 0; // stores index of current option in long_options array 
	struct option current_longopt; 
	
	int in_fd, out_fd, err_fd; 		// stores the in, out, and err arguments
	char* cmd;	// stores the cmd and its arg'
	// Do we need to worry about the number of possible args??
	char* cmd_args[10];
	
	while(1){
		opterr = 0; // Silence getopt errors 
		// Before parsing, check for valid optind -- we should be done if this happens 
		if (optind >= argc)
			break; 
		
		optchar = getopt_long(argc, argv, ":", long_options, &long_index); 
		
		/* If no more options, escape */ 
		if (optchar == -1)
			break; 
		
		if(verbose_flag){
			// verbose flag is set 
			// Output command along with operands 
			// Because --command has multiple arguments, output it specifically 
			// in the switch statement block
			if (optchar == 'r' || optchar == 'w'){
				current_longopt = long_options[long_index]; 
				printf("--%s ", current_longopt.name); 
				printf("%s\n", optarg); 
			}
		}
		
		// If necessary, make file desc table bigger
		if (table_index == TABLE_SIZE){
			table_size *= 2; 
			int* a = (int*) realloc(file_desc_table, table_size * sizeof(int)); 
			if(!a){
				fprintf(stderr, "Reallocation for file descriptor table failed. Exiting.\n"); 
				exit(1);
			}
		}
		
		int arg_cnt = 0; 
		switch(optchar){
			case 0: 
				// getopt_long() set a flag 
				break; 
			case 'r': 
				// open a file for reading; store real fd into descriptor table 
				filename = optarg; 
				fd = open(filename, O_RDONLY); 
				file_desc_table[table_index] = fd;
				table_index++; 
				break; 
				// Check for errors 
			case 'w': 
				// open a file for reading; store real fd into descriptor table 
				filename = optarg; 
				fd = open(filename, O_WRONLY); 
				file_desc_table[table_index] = fd;
				table_index++; 
				break; 
				// Check for errors 
			case 'c': 
				// execute a shell command 
				// the first 3 command-line args should be input, output, error streams
				// that refer to logical file descriptors 
				
				// input fd 
				if (optind < argc){
					in_fd = atoi(argv[optind-1]);
					if (in_fd >= table_index){
						fprintf(stderr, "Invalid standard input file descriptor specified. Continuing.\n");
						// exit(1); 
					}
			
					// printf("%d\n", in_fd); 
				}
				// output fd 
				if (optind < argc){
					out_fd = atoi(argv[optind++]); 
					if (out_fd >= table_index){
						fprintf(stderr, "Invalid standard output file descriptor specified. Continuing.\n");
						// exit(1); 
					}
					// printf("%d\n", out_fd); 
				}
				// error fd 
				if (optind < argc){
					err_fd = atoi(argv[optind++]);
					if (err_fd >= table_index){
						printf("%d\n", err_fd); 
						fprintf(stderr, "Invalid standard error file descriptor specified. Continuing.\n");
						// exit(1); 
					}
					// printf("%d\n", err_fd); 
				}
				// cmd to be executed 
				if (optind < argc){
					cmd = argv[optind++]; 
					cmd_args[arg_cnt] = cmd; 
					arg_cnt++; 
					// printf("%s\n", cmd); 
				}
				
				while(1){
					if(optind < argc){
						int temp = optind; 
						optchar = getopt_long(argc, argv, "", long_options, &long_index); 
						if(optchar == 'r' || optchar == 'w' || optchar == 'c' || optchar == 'v'){
							optind = temp; 
							break; 
						}
						else{
							optind = temp; 
							cmd_args[arg_cnt] = argv[optind++];  
							arg_cnt++;
						}
					}
					// no arguments left to parse
					else 
						// optind is greater than/equal to argc 
						break; 
				}
				
				// cmd_arg array passed to execvp must be terminated by NULL 
				cmd_args[arg_cnt] = NULL; 
				
				// Handle verbose flag, if set
				if (verbose_flag){
					fprintf(stdout, "--command %d %d %d ", in_fd, out_fd, err_fd); 
					int j;
					for(j=0; j<arg_cnt; j++)
					// Not sure why this works
						fprintf(stdout, "%s ", cmd_args[j]); 
					printf("\n"); 
				}
				
				// Assign fds given to --command to existing in, out, err streams (0, 1, 2) 
				dup2(file_desc_table[in_fd], 0); 
				dup2(file_desc_table[out_fd], 1); 
				dup2(file_desc_table[err_fd], 2); 
				
				pid_t pid = fork(); 
				if(pid == 0){
					int status = execvp(cmd, cmd_args); 
					if(status == -1){ 
						fprintf(stderr, "Failed to execute shell command. Continuing.\n"); 
						printf("%s\n", usage); 
						//exit(1);  
					}
				}
				else if(pid > 0){
					// parent process
					int child_status; 
					waitpid(pid, &child_status, 0); 
				}
				
				else {
					// fork failed
					fprintf(stderr, "Program failed to fork new child process. Command not executed.\n"); 
					// exit(1); 
				}
					
				break; 	
			case ':': 
				/* missing option argument; but if : is not first character of optstring, 
				this case is lumped into '?' case */ 
				fprintf(stderr, "Option is missing operand(s). Continuing.\n");  
				break;
			case '?': 
			default: 
				fprintf(stderr, "What?\n"); 
				/* invalid option specified */ 
				fprintf(stderr, "%s: option '-%c' is invalid: option ignored\n", argv[0], optopt); 
				break; 
		}
	}
	
	// Testing 
	// Close file descriptors here
	// Free allocated memory
	
	int i; 
	for(i=0; i < table_index; i++)
		close(file_desc_table[table_index]); 
	free(file_desc_table); 
	return 0; 
}


/* Notes:
malloc can't be used in a global scope (e.g. has to be used inside main function)
*/
